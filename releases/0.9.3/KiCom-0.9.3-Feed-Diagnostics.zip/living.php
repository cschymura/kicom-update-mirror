<?php
declare(strict_types=1);

/* KiCom Living Architecture 0.9.1 */
function kicomLivingDir(): string { return kicomVarDir().'/living'; }
function kicomEvolutionDir(): string { return kicomVarDir().'/evolution'; }
function kicomEvolutionCandidatesDir(): string { return kicomEvolutionDir().'/candidates'; }
function kicomEvolutionHistoryDir(): string { return kicomEvolutionDir().'/history'; }
function kicomGuardianFile(): string { return kicomLivingDir().'/guardian.json'; }
function kicomLivingEventsFile(): string { return kicomLivingDir().'/events.jsonl'; }

function kicomLivingEnsure(): bool {
    foreach([kicomLivingDir(),kicomEvolutionDir(),kicomEvolutionCandidatesDir(),kicomEvolutionHistoryDir(),kicomVarDir().'/quarantine',kicomVarDir().'/genome'] as $d){
        if(!is_dir($d)&&!@mkdir($d,0700,true)&&!is_dir($d))return false;
    }
    if(!defined('KICOM_RECOVERY_EMBEDDED'))define('KICOM_RECOVERY_EMBEDDED',true);
    require_once __DIR__.'/recovery.php';
    if(!rkEnsureDirs())return false;
    if(!is_file(kicomGuardianFile())){
        try{$key=bin2hex(random_bytes(24));}catch(Throwable $e){$key=hash('sha256',uniqid('',true));}
        $row=['key_hash'=>hash('sha256',$key),'created_at'=>gmdate('c'),'hint'=>'Full key is intentionally shown only in admin runtime.','key_plain'=>$key];
        if(@file_put_contents(kicomGuardianFile(),json_encode($row,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES),LOCK_EX)===false)return false;@chmod(kicomGuardianFile(),0600);
    }
    $trust=rkTrust();if($trust===null){$boot=rkBootstrapTrust(false);if(!$boot['ok'])return false;}
    return true;
}
function kicomLivingEvent(string $type,string $severity='info',array $data=[]): void {
    if(!defined('KICOM_RECOVERY_EMBEDDED'))define('KICOM_RECOVERY_EMBEDDED',true);require_once __DIR__.'/recovery.php';rkEvent($type,$severity,$data);
}
function kicomLivingStatus(): array {
    kicomLivingEnsure();$s=rkScan();$events=0;if(is_file(kicomLivingEventsFile())){$h=@fopen(kicomLivingEventsFile(),'rb');if($h){while(!feof($h)){if(fgets($h)!==false)$events++;}fclose($h);}}
    $candidates=count(glob(kicomEvolutionCandidatesDir().'/*.json')?:[]);
    return $s+['events'=>$events,'candidates'=>$candidates];
}
function kicomGuardianPlainKey(): ?string {
    $r=is_file(kicomGuardianFile())?json_decode((string)@file_get_contents(kicomGuardianFile()),true):null;return is_array($r)&&is_string($r['key_plain']??null)?$r['key_plain']:null;
}
function kicomRotateGuardianKey(): ?string {
    kicomLivingEnsure();try{$key=bin2hex(random_bytes(24));}catch(Throwable $e){$key=hash('sha256',uniqid('',true));}
    $row=['key_hash'=>hash('sha256',$key),'created_at'=>gmdate('c'),'key_plain'=>$key];$j=json_encode($row,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES);
    if($j===false||@file_put_contents(kicomGuardianFile(),$j,LOCK_EX)===false)return null;@chmod(kicomGuardianFile(),0600);kicomLivingEvent('guardian_key_rotated');return $key;
}
function kicomLivingExperience(int $limit=500): array {
    kicomLivingEnsure();$rows=[];$f=kicomLivingEventsFile();if(is_file($f)){
        $lines=@file($f,FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES)?:[];foreach(array_slice($lines,-$limit) as $line){$r=json_decode($line,true);if(is_array($r))$rows[]=$r;}
    }
    $types=[];$paths=[];$severity=[];foreach($rows as $r){$t=(string)($r['type']??'unknown');$types[$t]=($types[$t]??0)+1;$sev=(string)($r['severity']??'info');$severity[$sev]=($severity[$sev]??0)+1;$d=$r['data']??[];if(is_array($d)){foreach(['path','component'] as $k)if(is_string($d[$k]??null)){$p=$d[$k];$paths[$p]=($paths[$p]??0)+1;}foreach(['repaired','quarantined','files'] as $lk)foreach(($d[$lk]??[]) as $p)if(is_string($p))$paths[$p]=($paths[$p]??0)+1;}}
    arsort($types);arsort($paths);arsort($severity);return ['events'=>count($rows),'types'=>$types,'paths'=>$paths,'severity'=>$severity,'recent'=>array_slice(array_reverse($rows),0,20)];
}
function kicomLivingInsights(): array {
    $e=kicomLivingExperience(1000);$insights=[];$add=function(string $kind,string $priority,string $evidence,string $hypothesis,string $suggested)use(&$insights){$insights[]=['kind'=>$kind,'priority'=>$priority,'evidence'=>$evidence,'hypothesis'=>$hypothesis,'suggested_action'=>$suggested];};
    foreach(($e['paths']??[]) as $path=>$count){if((int)$count>=2)$add('repeated_component_event',(int)$count>=4?'high':'medium',$path.' x'.(int)$count,'Repeated events around the same component may indicate a recurring root cause rather than isolated corruption.','Review the component history and consider a candidate mutation that removes the recurring cause or adds an earlier invariant/preflight.');}
    $types=$e['types']??[];
    if((int)($types['healing_blocked']??0)>0)$add('kernel_drift','high','healing_blocked x'.(int)$types['healing_blocked'],'Recovery-kernel drift cannot be healed by the normal phenotype.','Inspect the recovery kernel manually; only promote a kernel mutation with incremented kernel_revision and explicit human confirmation.');
    if((int)($types['unknown_quarantine']??0)>0)$add('unexpected_code','high','unknown_quarantine x'.(int)$types['unknown_quarantine'],'Unexpected executable/control artifacts reached the KiCom tree.','Investigate origin and credentials; keep artifacts quarantined unless a reviewed genome mutation explicitly incorporates them.');
    if((int)($types['candidate_evaluated']??0)>0){$rejected=0;foreach(($e['recent']??[]) as $r)if(($r['type']??'')==='candidate_evaluated'&&($r['severity']??'')==='warn')$rejected++;if($rejected>0)$add('candidate_rejection','medium','recent rejected candidates '.$rejected,'Candidate mutations are failing deterministic fitness checks.','Use the failed fitness evidence to revise the mutation before another promotion attempt.');}
    if(empty($insights))$add('baseline','low','no recurring adverse pattern','No recurring fault pattern is currently visible in the retained experience window.','Continue observing; do not mutate the genome without evidence or an explicit improvement goal.');
    return ['generated_at'=>gmdate('c'),'events_considered'=>(int)($e['events']??0),'insights'=>$insights];
}
function kicomGenomeCurrent(): ?array {
    kicomLivingEnsure();$r=rkLoadGenome();return $r['ok']?$r['genome']:null;
}
function kicomGenomeValidateArray(array $g,array $packageEntries=[]): array {
    if((int)($g['schema']??0)!==1||!is_string($g['id']??null)||!is_string($g['version']??null)||!is_string($g['parent']??null)||!is_array($g['components']??null))return ['ok'=>false,'code'=>'GENOME_SCHEMA_INVALID'];
    if(!preg_match('/^[A-Za-z0-9._-]{3,80}$/',(string)$g['id'])||!preg_match('/^[0-9]+\.[0-9]+\.[0-9]+$/',(string)$g['version']))return ['ok'=>false,'code'=>'GENOME_ID_OR_VERSION_INVALID'];
    if((int)($g['generation']??0)<1||(int)($g['kernel_revision']??0)<1||trim((string)($g['mutation_reason']??''))==='')return ['ok'=>false,'code'=>'GENOME_LINEAGE_METADATA_INVALID'];
    $requiredInvariants=['no-arbitrary-shell','no-arbitrary-sql','no-arbitrary-remote-fetch','human-gated-new-capabilities','separate-genome-memory-phenotype','autonomous-heal-trusted-state-only','production-writes-human-approved','recovery-kernel-not-auto-healed','unknown-code-quarantine-before-use'];
    $inv=array_values(array_filter($g['invariants']??[],'is_string'));foreach($requiredInvariants as $i)if(!in_array($i,$inv,true))return ['ok'=>false,'code'=>'GENOME_INVARIANT_MISSING','invariant'=>$i];
    $health=array_values(array_filter($g['healthchecks']??[],'is_string'));foreach(['HELLO','BOOTSTRAP','LIVING_STATUS'] as $h)if(!in_array($h,$health,true))return ['ok'=>false,'code'=>'GENOME_HEALTHCHECK_MISSING','healthcheck'=>$h];
    $seen=[];foreach($g['components'] as $c){if(!is_array($c))return ['ok'=>false,'code'=>'GENOME_COMPONENT_INVALID'];$p=kicomSafeUpdatePath((string)($c['path']??''));$sha=strtolower((string)($c['sha256']??''));if($p===null||isset($seen[$p])||!preg_match('/^[a-f0-9]{64}$/',$sha))return ['ok'=>false,'code'=>'GENOME_COMPONENT_INVALID'];$seen[$p]=true;if($packageEntries&&(!isset($packageEntries[$p])||!hash_equals($sha,(string)($packageEntries[$p]['sha256']??''))))return ['ok'=>false,'code'=>'GENOME_COMPONENT_HASH_MISMATCH','path'=>$p];}
    foreach(['lib.php','index.php','api.php','admin.php','living.php','recovery.php','guardian.php','.htaccess','robots.txt','genome/.htaccess','memory/.htaccess','stage/.htaccess','var/.htaccess'] as $p)if(!isset($seen[$p]))return ['ok'=>false,'code'=>'GENOME_REQUIRED_COMPONENT_MISSING','path'=>$p];
    return ['ok'=>true,'kernel_revision'=>(int)$g['kernel_revision'],'generation'=>(int)$g['generation'],'components'=>count($seen)];
}
function kicomEvolutionCandidateFile(string $id): string { return kicomEvolutionCandidatesDir().'/'.$id.'.json'; }
function kicomEvolutionPackageFile(string $id): string { return kicomEvolutionCandidatesDir().'/'.$id.'.zip'; }
function kicomEvolutionSafeId(string $id): ?string { $id=strtolower(trim($id));return preg_match('/^[a-f0-9]{16,64}$/',$id)?$id:null; }
function kicomEvolutionFitness(array $check): array {
    $tests=[];$score=0;$max=0;$add=function(string $name,bool $ok,int $weight,string $detail='')use(&$tests,&$score,&$max){$max+=$weight;if($ok)$score+=$weight;$tests[]=['name'=>$name,'ok'=>$ok,'weight'=>$weight,'detail'=>$detail];};
    $add('package_manifest',!empty($check['ok']),15,empty($check['ok'])?(string)($check['code']??'invalid'):'verified');if(empty($check['ok']))return ['score'=>0,'max'=>$max,'passed'=>false,'tests'=>$tests];
    $g=$check['genome']??null;$gv=is_array($g)?kicomGenomeValidateArray($g,(array)($check['entries']??[])):['ok'=>false,'code'=>'GENOME_MISSING'];$add('genome_schema',!empty($gv['ok']),20,(string)($gv['code']??'valid'));
    $current=kicomGenomeCurrent();$parentOk=is_array($g)&&is_array($current)&&hash_equals((string)($g['parent']??''),(string)($current['id']??''));$add('lineage_parent',$parentOk,12,$parentOk?'matches-current':'parent-mismatch');
    $generationOk=is_array($g)&&is_array($current)&&(int)($g['generation']??0)===(int)($current['generation']??0)+1;$add('lineage_generation',$generationOk,8,$generationOk?'next-generation':'generation-mismatch');
    $reasonOk=is_array($g)&&trim((string)($g['mutation_reason']??''))!=='';$add('mutation_reason',$reasonOk,5,$reasonOk?'declared':'missing');
    $versionOk=version_compare((string)($check['version']??'0.0.0'),KICOM_VERSION,'>');$add('version_progression',$versionOk,10,(string)($check['version']??''));
    $add('php_syntax',true,12,'validated during package inspection');
    $privacy=isset($check['entries']['.htaccess'],$check['entries']['robots.txt'],$check['entries']['genome/.htaccess'],$check['entries']['memory/.htaccess'],$check['entries']['stage/.htaccess'],$check['entries']['var/.htaccess']);$add('privacy_controls',$privacy,8,$privacy?'present':'missing');
    $idx=(string)($check['entries']['index.php']['content']??'');$iface=$idx!==''&&str_contains($idx,"case 'HELLO'")&&str_contains($idx,"case 'BOOTSTRAP'")&&str_contains($idx,"case 'LIVING_STATUS'")&&str_contains($idx,"case 'DESCRIBE'");$add('static_interface_regression',$iface,10,$iface?'core KCL surfaces present':'required KCL surface missing');
    $kernelChanged=(bool)($check['kernel_update']??false);$curKr=(int)($current['kernel_revision']??0);$newKr=(int)($g['kernel_revision']??0);$declared=$kernelChanged?$newKr>$curKr:$newKr===$curKr;$add('kernel_change_declared',$declared,10,$kernelChanged?'kernel-update':'kernel-stable');
    $add('human_gate_preserved',is_array($g)&&in_array('human-gated-new-capabilities',$g['invariants']??[],true),5,'invariant');
    $passed=$score===$max;return ['score'=>$score,'max'=>$max,'percent'=>$max?round($score*100/$max,1):0,'passed'=>$passed,'tests'=>$tests];
}
function kicomEvolutionStageCandidate(string $sourcePath,string $originalName='candidate.zip'): array {
    if(!kicomLivingEnsure())return ['ok'=>false,'code'=>'LIVING_STORAGE_UNAVAILABLE'];$check=kicomSelfUpdateZipInspect($sourcePath);if(!$check['ok'])return $check;
    if(version_compare((string)$check['version'],KICOM_VERSION,'<='))return ['ok'=>false,'code'=>'VERSION_NOT_NEWER'];
    $fitness=kicomEvolutionFitness($check);$id=substr(hash('sha256',(string)$check['zip_sha256'].'|'.microtime(true)),0,24);$pkg=kicomEvolutionPackageFile($id);if(!@copy($sourcePath,$pkg))return ['ok'=>false,'code'=>'CANDIDATE_STORE_FAILED'];@chmod($pkg,0600);
    $g=$check['genome']??[];$row=['id'=>$id,'original_name'=>basename($originalName),'created_at'=>gmdate('c'),'from_version'=>KICOM_VERSION,'to_version'=>$check['version'],'package_sha256'=>$check['zip_sha256'],'manifest_sha256'=>$check['manifest_sha256'],'genome_id'=>is_array($g)?($g['id']??''):'','parent'=>is_array($g)?($g['parent']??''):'','mutation_reason'=>is_array($g)?($g['mutation_reason']??''):'','kernel_update'=>(bool)($check['kernel_update']??false),'fitness'=>$fitness,'status'=>$fitness['passed']?'fit':'rejected'];
    $j=json_encode($row,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES);if($j===false||@file_put_contents(kicomEvolutionCandidateFile($id),$j,LOCK_EX)===false){@unlink($pkg);return ['ok'=>false,'code'=>'CANDIDATE_META_FAILED'];}@chmod(kicomEvolutionCandidateFile($id),0600);
    kicomLivingEvent('candidate_evaluated',$fitness['passed']?'info':'warn',['candidate'=>$id,'version'=>$check['version'],'fitness'=>$fitness['percent'],'genome_id'=>$row['genome_id']]);return ['ok'=>true]+$row;
}
function kicomEvolutionCandidates(): array {
    kicomLivingEnsure();$rows=[];foreach(glob(kicomEvolutionCandidatesDir().'/*.json')?:[] as $f){$r=json_decode((string)@file_get_contents($f),true);if(is_array($r))$rows[]=$r;}usort($rows,fn($a,$b)=>strcmp((string)($b['created_at']??''),(string)($a['created_at']??'')));return $rows;
}
function kicomEvolutionCandidate(string $id): ?array { $id=kicomEvolutionSafeId($id);if($id===null)return null;$f=kicomEvolutionCandidateFile($id);if(!is_file($f))return null;$r=json_decode((string)@file_get_contents($f),true);return is_array($r)?$r:null; }
function kicomEvolutionPromote(string $id): array {
    $c=kicomEvolutionCandidate($id);if($c===null)return ['ok'=>false,'code'=>'CANDIDATE_NOT_FOUND'];if(empty($c['fitness']['passed']))return ['ok'=>false,'code'=>'CANDIDATE_NOT_FIT'];$pkg=kicomEvolutionPackageFile((string)$c['id']);if(!is_file($pkg))return ['ok'=>false,'code'=>'CANDIDATE_PACKAGE_MISSING'];$r=kicomStageSelfUpdatePackage($pkg,(string)$c['original_name']);if(!$r['ok'])return $r;$c['status']='promoted';$c['promoted_at']=gmdate('c');@file_put_contents(kicomEvolutionCandidateFile((string)$c['id']),json_encode($c,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES),LOCK_EX);kicomLivingEvent('candidate_promoted','info',['candidate'=>$id,'to_version'=>$c['to_version']]);return ['ok'=>true]+$r;
}
function kicomLivingCommitGenomeAfterInstall(): array {
    if(!defined('KICOM_RECOVERY_EMBEDDED'))define('KICOM_RECOVERY_EMBEDDED',true);require_once __DIR__.'/recovery.php';$r=rkBootstrapTrust(true);kicomLivingEvent('genome_promoted',$r['ok']?'info':'error',['version'=>$r['version']??'','genome_id'=>$r['genome_id']??'','result'=>$r['ok']]);return $r;
}
